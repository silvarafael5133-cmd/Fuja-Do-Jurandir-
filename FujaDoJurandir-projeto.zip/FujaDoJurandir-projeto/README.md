# Fuja do Jurandir 3D — by Kaka Studios

Pasta do projeto:
- `jogo/index.html` — o jogo completo (um arquivo só). Todas as versões abaixo usam ele.
- `android/` — projeto Android (APK). Android 9 (API 28) até 16+ (targetSdk 35). Só roda deitado (paisagem), como o Free Fire.
- `desktop/` — app de PC com Electron 22 (último que roda no **Windows 7/8/8.1**; também Windows 10/11 e **Linux**).
- `.github/workflows/build.yml` — gera tudo sozinho na nuvem do GitHub.

> Importante: o APK e os executáveis precisam ser compilados. Isso **não foi feito aqui** (sem Android SDK/internet).
> O projeto está pronto, é só rodar um dos caminhos abaixo.

## Jeito mais fácil (sem instalar nada): GitHub Actions
1. Crie um repositório no GitHub e envie **o conteúdo desta pasta** (incluindo `.github`).
2. Aba **Actions → Build Fuja do Jurandir → Run workflow**.
3. Quando terminar, baixe em **Artifacts**:
   - `FujaDoJurandir-android-apk` → `app-debug.apk` (instala direto no celular)
   - `FujaDoJurandir-windows` → `.zip` 64-bit e 32-bit (descompacta e abre o .exe)
   - `FujaDoJurandir-linux` → `.tar.gz` e `.AppImage`

## Android Studio (APK no seu PC)
1. Abra a pasta `android/` no Android Studio (JDK 17).
2. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. O arquivo fica em `android/app/build/outputs/apk/debug/app-debug.apk`.
   Para um APK "release" assinado: **Build → Generate Signed Bundle / APK**.

## PC manual
```
cd desktop
npm install
npm start            # testar
npm run dist-win     # gera .zip do Windows (rodar no Windows)
npm run dist-linux   # gera .tar.gz e .AppImage (rodar no Linux)
```

## GameJolt
- **HTML5:** envie `Fuja-do-Jurandir-HTML5.zip` (tem `index.html` na raiz). Tamanho sugerido: 1280x720 (o jogo se ajusta a HD, FHD e WQHD).
- **Android:** envie o `.apk`.
- **Windows / Linux:** envie os arquivos de `desktop/dist` (ou do Artifacts).

## Controles
- Celular: analógico fixo à esquerda, arraste a tela pra olhar (cima/baixo/lados), ✋ interage.
- PC: WASD anda • mouse olha (clique no jogo) • Shift corre • F lanterna • E ou clique interage • setas olham • Esc menu • F11 tela cheia.
